//
//  lyricsTests.swift
//  lyricsTests
//
//  Created by MacBook on 22/04/25.
//

import Testing
@testable import lyrics

struct lyricsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
